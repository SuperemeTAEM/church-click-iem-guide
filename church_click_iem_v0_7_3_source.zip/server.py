import asyncio,json,time,sys
from pathlib import Path
from aiohttp import web,WSMsgType
import security
from phone_access import PORT, list_addresses, phone_qr
ROOT=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parent))
clients={};channels={};counter=0
connection_lock=asyncio.Lock()
state={'type':'state','running':False,'bpm':100,'beats':4,'subdivision':1,'accent':True,'startAt':0,'revision':0}
def status():
 return {**state,'serverTime':time.time()*1000,'connections':len(clients),'channels':[{'channel':v['channel'],'name':v['name'],'connected':True} for v in clients.values() if v['role']=='receiver']}
async def broadcast():
 msg=status()
 for ws in list(clients):
  try:await ws.send_json(msg)
  except Exception:pass
async def handler(req):
 global counter
 async with connection_lock:
  role='admin' if req.query.get('role')=='admin' else 'receiver'
  if not (security.admin(req) if role=='admin' else security.receiver(req)):
   raise web.HTTPForbidden(text='인증이 필요합니다.')
  if not security.connections.allow(req.remote):
   raise web.HTTPTooManyRequests()
  if len(clients)>=10 or (role=='admin' and sum(v['role']=='admin' for v in clients.values())>=2):
   raise web.HTTPServiceUnavailable(text='연결 한도에 도달했습니다.')
  ws=web.WebSocketResponse(heartbeat=15,max_msg_size=4096);await ws.prepare(req)
  if role=='receiver':
   used={v['channel'] for v in clients.values() if v['role']=='receiver'}
   channel=next((i for i in range(1,9) if i not in used),None)
   if channel is None:
    await ws.send_json({'type':'error','message':'8개 수신 채널이 모두 사용 중입니다.'});await ws.close();return ws
  else:channel=0
  clients[ws]={'role':role,'channel':channel,'name':f'CH{channel}' if channel else 'PC'}
 await ws.send_json({'type':'welcome','channel':channel})
 await broadcast()
 limiter=security.RateLimit(30,1,1)
 try:
  async for msg in ws:
   if not limiter.allow('messages'):
    await ws.close(code=1008,message=b'Rate limit');break
   if msg.type!=WSMsgType.TEXT:continue
   try:d=json.loads(msg.data)
   except ValueError:continue
   if not isinstance(d,dict):continue
   kind=d.get('type')
   if kind=='ping':await ws.send_json({'type':'pong','id':d.get('id'),'serverTime':time.time()*1000});continue
   if kind=='hello' and role=='receiver':
    clients[ws]['name']=str(d.get('name',''))[:24] or f'CH{channel}';await broadcast();continue
   if kind=='get':await ws.send_json(status());continue
   if role!='admin':continue
   if kind=='set':
    try:
     bpm=int(d.get('bpm',state['bpm']))
     beats=int(d.get('beats',state['beats']))
     subdivision=int(d.get('subdivision',state['subdivision']))
     accent=d.get('accent',state['accent'])
     if not 30<=bpm<=300 or not 1<=beats<=12 or subdivision not in (1,2,3,4,8) or type(accent) is not bool:continue
    except (ValueError,TypeError,OverflowError):continue
    state.update(bpm=bpm,beats=beats,subdivision=subdivision,accent=accent)
    if state['running']:state['startAt']=time.time()*1000+2000
   elif kind=='tempoStep':
    delta=d.get('delta')
    if type(delta) is not int or delta not in (-10,-5,5,10):continue
    bpm=max(30,min(300,state['bpm']+delta))
    if bpm==state['bpm']:continue
    state['bpm']=bpm
    if state['running']:state['startAt']=time.time()*1000+2000
   elif kind=='start':state['running']=True;state['startAt']=time.time()*1000+2000
   elif kind=='stop':state['running']=False
   else:continue
   state['revision']+=1;await broadcast()
 finally:
  clients.pop(ws,None);await broadcast()
 return ws
async def page(req):
 if req.path=='/' and not security.receiver(req):
  return web.Response(text=security.JOIN_PAGE,content_type='text/html')
 return web.FileResponse(ROOT/('control.html' if req.path=='/control' else 'receiver.html'))
async def icon_asset(req):
 return web.FileResponse(ROOT/req.match_info['icon'])

async def health(req):
 return web.json_response({'app':'church-click-iem','version':'0.7.3'})

def create_app():
 app=web.Application(middlewares=[security.protect],client_max_size=4096)
 app.router.add_post('/join',security.join)
 app.router.add_get('/api/join-code',security.join_code)
 app.router.add_get('/api/health',health)
 app.router.add_get('/{icon:app[.](?:svg|png|ico)}',icon_asset)
 app.router.add_get('/',page)
 app.router.add_get('/control',page)
 app.router.add_get('/ws',handler)
 app.router.add_get('/api/phone-addresses',list_addresses)
 app.router.add_get('/api/phone-qr',phone_qr)
 return app

if __name__=='__main__':
 print(f'PC: http://127.0.0.1:{PORT}/control?token={security.ADMIN_TOKEN}')
 web.run_app(create_app(),host='0.0.0.0',port=PORT)


