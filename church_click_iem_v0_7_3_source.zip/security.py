"""Per-run credentials and bounded request limits for the local IEM server."""
import secrets
import time
from collections import OrderedDict
from ipaddress import ip_address
from aiohttp import web

ADMIN_TOKEN = secrets.token_urlsafe(32)
RECEIVER_TOKEN = secrets.token_urlsafe(32)
JOIN_CODE = str(secrets.randbelow(90000000) + 10000000)

class RateLimit:
    def __init__(self, limit, seconds, capacity=1024):
        self.limit = limit
        self.seconds = seconds
        self.capacity = capacity
        self.entries = OrderedDict()

    def allow(self, key):
        now = time.monotonic()
        while self.entries and next(iter(self.entries.values()))[0] <= now - self.seconds:
            self.entries.popitem(last=False)
        start, count = self.entries.get(key, (now, 0))
        if count >= self.limit:
            return False
        if key not in self.entries and len(self.entries) >= self.capacity:
            return False
        self.entries[key] = (start, count + 1)
        return True

requests = RateLimit(180, 60)
joins = RateLimit(5, 60)
connections = RateLimit(20, 60)

def cookie_name(req, role):
    return 'iem_' + role + '_' + req.host.rsplit(':', 1)[-1]

def admin(req):
    return req.remote in ('127.0.0.1', '::1') and secrets.compare_digest(req.cookies.get(cookie_name(req, 'admin'), ''), ADMIN_TOKEN)

def receiver(req):
    return secrets.compare_digest(req.cookies.get(cookie_name(req, 'receiver'), ''), RECEIVER_TOKEN)

def set_cookie(req, response, role, value):
    response.set_cookie(cookie_name(req, role), value, httponly=True, samesite='Strict', path='/')
    return response

@web.middleware
async def protect(req, handler):
    try:
        ip_address(req.host.rsplit(':', 1)[0].strip('[]'))
    except ValueError:
        raise web.HTTPForbidden(text='IP 주소로 접속하세요.')
    origin = req.headers.get('Origin')
    if origin and origin != 'http://' + req.host:
        raise web.HTTPForbidden(text='다른 사이트에서의 요청은 허용되지 않습니다.')
    if not requests.allow(req.remote):
        raise web.HTTPTooManyRequests(text='요청이 많습니다. 1분 후 다시 시도하세요.')
    if req.path == '/control' and req.query.get('token'):
        if req.remote not in ('127.0.0.1', '::1') or not secrets.compare_digest(req.query['token'], ADMIN_TOKEN):
            raise web.HTTPForbidden(text='제어 권한이 없습니다.')
        return set_cookie(req, web.HTTPFound('/control'), 'admin', ADMIN_TOKEN)
    if req.path in ('/control', '/api/phone-addresses', '/api/phone-qr', '/api/join-code') and not admin(req):
        raise web.HTTPForbidden(text='PC 앱에서 제어 화면을 여세요.')
    response = await handler(req)
    response.headers['Cache-Control'] = 'no-store'
    response.headers['Referrer-Policy'] = 'no-referrer'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    return response

JOIN_PAGE = '''<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Church Click IEM 참가</title><body style="font:18px system-ui;background:#101823;color:white;padding:24px"><h1>Church Click IEM</h1><p>PC 인이어 관리 화면의 8자리 참가 코드를 입력하세요.</p><form method="post" action="/join"><input name="code" inputmode="numeric" pattern="[0-9]{8}" maxlength="8" required autocomplete="off" aria-label="참가 코드"><button>참가하기</button></form><p>유선 이어폰을 연결한 뒤 오디오를 켜세요.</p></body></html>'''

async def join(req):
    if not joins.allow(req.remote):
        raise web.HTTPTooManyRequests(text='참가 시도는 1분에 5회까지 가능합니다. 잠시 후 다시 시도하세요.')
    data = await req.post()
    if not secrets.compare_digest(str(data.get('code', '')), JOIN_CODE):
        return web.Response(text=JOIN_PAGE.replace('<form', '<p>참가 코드를 다시 확인하세요.</p><form'), content_type='text/html', status=403)
    return set_cookie(req, web.HTTPFound('/'), 'receiver', RECEIVER_TOKEN)

async def join_code(req):
    return web.json_response({'code': JOIN_CODE})
