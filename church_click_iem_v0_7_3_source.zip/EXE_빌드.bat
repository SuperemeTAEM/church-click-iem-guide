@echo off
cd /d "%~dp0"
python -m pip install -r requirements-build.txt
python -m PyInstaller --noconfirm --onefile --windowed --name ChurchClickIEM --icon "app.ico" --add-data "app.ico;." --add-data "app.svg;." --add-data "app.png;." --add-data "control.html;." --add-data "receiver.html;." launcher.py
pause

