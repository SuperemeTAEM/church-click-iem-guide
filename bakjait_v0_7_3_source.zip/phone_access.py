import os
import socket
from ipaddress import IPv4Address

import psutil
import qrcode
from aiohttp import web
from qrcode.image.svg import SvgPathFillImage

PORT = int(os.environ.get('CHURCH_CLICK_PORT', '18765'))
if not 1 <= PORT <= 65535:
    raise ValueError('CHURCH_CLICK_PORT must be between 1 and 65535')


def network_addresses():
    active = psutil.net_if_stats()
    addresses = {}
    for name, entries in psutil.net_if_addrs().items():
        if name not in active or not active[name].isup:
            continue
        for entry in entries:
            if entry.family != socket.AF_INET:
                continue
            address = IPv4Address(entry.address)
            if address.is_loopback or address.is_unspecified or address.is_multicast:
                continue
            ip = str(address)
            addresses.setdefault(ip, {
                'ip': ip, 'interface': name, 'url': f'http://{ip}:{PORT}/',
            })

    preferred = None
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as route:
        try:
            # UDP route lookup selects a local address without sending a packet.
            route.connect(('8.8.8.8', 80))
            preferred = route.getsockname()[0]
        except OSError:
            pass
    return sorted(addresses.values(), key=lambda item: (
        item['ip'] != preferred,
        IPv4Address(item['ip']).is_link_local,
        item['interface'].casefold(),
        item['ip'],
    ))


async def list_addresses(request):
    return web.json_response(network_addresses(), headers={'Cache-Control': 'no-store'})


async def phone_qr(request):
    selected = next((item for item in network_addresses()
                     if item['ip'] == request.query.get('ip')), None)
    if selected is None:
        raise web.HTTPNotFound()
    qr = qrcode.make(selected['url'], image_factory=SvgPathFillImage, border=4)
    return web.Response(body=qr.to_string(), content_type='image/svg+xml',
                        headers={'Cache-Control': 'no-store'})

