"""Start the local server and desktop window."""
import asyncio
import socket
import threading
import urllib.request
import json
import webbrowser
import phone_access
import security
from aiohttp import web
from server import create_app, ROOT

ready = threading.Event()
errors = []

def reserve_socket():
    for port in range(phone_access.PORT, min(phone_access.PORT + 100, 65536)):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        try:
            sock.bind(('0.0.0.0', port))
            sock.listen(128)
            sock.setblocking(False)
            phone_access.PORT = port
            return sock
        except OSError:
            sock.close()
    raise RuntimeError('사용 가능한 포트를 찾지 못했습니다.')

async def serve():
    runner = None
    sock = None
    try:
        sock = reserve_socket()
        runner = web.AppRunner(create_app())
        await runner.setup()
        await web.SockSite(runner, sock).start()
        ready.set()
        await asyncio.Event().wait()
    except Exception as error:
        errors.append(str(error))
        ready.set()
    finally:
        if runner:
            await runner.cleanup()
        if sock:
            sock.close()

def main():
    threading.Thread(target=lambda: asyncio.run(serve()), daemon=True).start()
    if not ready.wait(10):
        raise RuntimeError('서버 시작 시간이 초과되었습니다.')
    if errors:
        raise RuntimeError('서버 시작 실패: ' + errors[0])
    url = f'http://127.0.0.1:{phone_access.PORT}'
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(url + '/api/health', timeout=3) as response:
        if json.load(response).get('app') != 'church-click-iem':
            raise RuntimeError('메트로놈 서버 연결을 확인하지 못했습니다.')
    try:
        import webview
        webview.create_window('박자잇 v0.7.3', url + '/control?token=' + security.ADMIN_TOKEN, width=980, height=780)
        webview.start(private_mode=False)
    except Exception:
        import tkinter as tk
        root = tk.Tk()
        root.title('박자잇 v0.7.3')
        root.iconbitmap(str(ROOT / 'app.ico'))
        tk.Label(root, text='이 창을 닫으면 메트로놈이 종료됩니다.').pack(padx=24, pady=24)
        tk.Button(root, text='제어 화면 열기', command=lambda: webbrowser.open(url + '/control?token=' + security.ADMIN_TOKEN)).pack(pady=12)
        webbrowser.open(url + '/control?token=' + security.ADMIN_TOKEN)
        root.mainloop()

if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, str(error), '박자잇 시작 오류', 16)
